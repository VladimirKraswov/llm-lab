# Trainer Runtime HF E2E Check

Распакуй архив в корень backend-проекта.

Запуск:

```bash
HF_TOKEN=hf_xxx node scripts/check-trainer-runtime-hf-e2e.js \
  --project-root . \
  --trainer-service-dir /path/to/trainer-service \
  --hf-repo XProger/test_2 \
  --base-image igortet/model-qwen-7b \
  --verbose
```

Если runtime image уже собран:

```bash
HF_TOKEN=hf_xxx node scripts/check-trainer-runtime-hf-e2e.js \
  --project-root . \
  --runtime-image forge-trainer-e2e:latest \
  --hf-repo XProger/test_2
```
